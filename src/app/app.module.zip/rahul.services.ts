export class Stationary
{
	provideStat()
	{
		return["Pen","Pencil","Marker","Book","Notebook"];
	}
}