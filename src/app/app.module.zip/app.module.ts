import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Stationary } from './rahul.services';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BuyCls } from './buy.component';
import { UseCls } from './use.component';
import { RepCls } from './report.component';

@NgModule({
  declarations: [
    AppComponent,
    BuyCls,
    UseCls,
    RepCls
  ],
  imports: [

    BrowserModule,
    AppRoutingModule
  ],
  providers: [Stationary],
  bootstrap: [AppComponent]
})
export class AppModule { }
