export class Participants
{
	provideDetails()
	{
		return["Rahul","Speaker","Yes","IT Department"];
	}
}