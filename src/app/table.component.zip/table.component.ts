import { Component } from '@angular/core';

@Component({
  selector: 'stock',
  template: `<table [border]="bdr">
  <tr>
  <td>No.</td>
  <td>Name</td>
  </tr>
  <tr>
  <td>1</td>
  <td>Rahul</td>
  </table>`
})
export class Table {

	bdr = 5;


}
